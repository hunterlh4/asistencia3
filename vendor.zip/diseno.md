# Sistema Asistencia
## Trabajador
### Seguimiento
### Cargo
### Direccion
#### Equipo
### Horario Detalle
#### Horario

## Asistencia
### Trabajador
## Boleta
### Trabajador
## Reporte
## Usuarios
## Log

## Usuarios Conectados
## Configuracion