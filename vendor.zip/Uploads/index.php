<?php
require_once '../Config/Config.php';
header('Location: '.BASE_URL.'errors');
// $uri = $_SERVER['REQUEST_URI'];
// echo "<script>console.log('URI actual: $uri');</script>";