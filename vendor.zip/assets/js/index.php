<?php
require_once '../../Config/Config.php';
header('Location: '.BASE_URL.'errors');