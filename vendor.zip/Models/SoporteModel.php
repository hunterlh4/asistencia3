<?php
class SoporteModel extends Query
{

    public function __construct()
    {
        parent::__construct();
    }
   
}
