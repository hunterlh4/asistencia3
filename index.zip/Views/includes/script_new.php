<!-- General JS Scripts -->
<script src="<?php echo BASE_URL; ?>assets/js/app.min.js"></script>

<script src="<?php echo BASE_URL; ?>assets/bundles/jquery-pwstrength/jquery.pwstrength.min.js"></script>
<script src="<?php echo BASE_URL; ?>assets/bundles/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="<?php echo BASE_URL; ?>assets/bundles/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
<script src="<?php echo BASE_URL; ?>assets/bundles/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>

<!-- Moment.js: EDITADO-->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.2/moment.min.js"></script> -->
<!--<script type="text/javascript" src="//cdn.datatables.net/plug-ins/1.10.24/dataRender/datetime.js"></script>-->
<!-- Locales for moment.js-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.19.4/locale/es.js"></script>-->
<!--<script src="https://cdn.datatables.net/plug-ins/1.10.15/sorting/datetime-moment.js"></script>-->


<script src="<?php echo BASE_URL; ?>assets/bundles/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
<script src="<?php echo BASE_URL; ?>assets/bundles/select2/dist/js/select2.full.min.js"></script>
<script src="<?php echo BASE_URL; ?>assets/bundles/jquery-selectric/jquery.selectric.min.js"></script>
<!--  -->
<script src="<?php echo BASE_URL; ?>assets/bundles/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
<script src="<?php echo BASE_URL; ?>assets/bundles/cleave-js/dist/cleave.min.js"></script>
<script src="<?php echo BASE_URL; ?>assets/bundles/cleave-js/dist/addons/cleave-phone.us.js"></script>
<script src="<?php echo BASE_URL; ?>assets/bundles/jquery-pwstrength/jquery.pwstrength.min.js"></script>
<!--  -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js" integrity="sha512-T/tUfKSV1bihCnd+MxKD0Hm1uBBroVYBOYSk1knyvQ9VyZJpc/ALb4P0r6ubwVPSGB2GvjeoMAJJImBG12TiaQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> -->
<script src="<?php echo BASE_URL; ?>assets/plantilla/chosen.jquery.js"></script>
<script src="<?php echo BASE_URL; ?>assets/js/jquery.fancybox.js"></script>

<!-- <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script> -->
<!-- JS Libraies DATATABLE -->
<script src="<?php echo BASE_URL; ?>assets/bundles/datatables/datatables.min.js"></script>
<script src="<?php echo BASE_URL; ?>assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo BASE_URL; ?>assets/js/datatables.js"></script>
<!--<script src="//cdn.rawgit.com/ashl1/datatables-rowsgroup/v1.0.0/dataTables.rowsGroup.js"></script>-->
<!-- <script src="https://cdn.datatables.net/rowgroup/1.2.0/js/dataTables.rowGroup.min.js"></script> -->
<script src="<?php echo BASE_URL; ?>assets/bundles/jquery-ui/jquery-ui.min.js"></script>

<script src="<?php echo BASE_URL; ?>assets/bundles/fullcalendar/main.js"></script>
<script src="<?php echo BASE_URL; ?>assets/bundles/fullcalendar/locales-all.js"></script>


<!-- Page Specific JS File -->
<!--<script src="assets/js/page/index.js"></script>-->
<!-- Template JS File -->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
<script src="<?php echo BASE_URL; ?>assets/js/scripts.js"></script>
<!-- Custom JS File -->
<script src="<?php echo BASE_URL; ?>assets/js/custom.js"></script>


<!-- Page Specific JS File -->


<!-- Mobiscroll -->
<script src="<?php echo BASE_URL; ?>assets/bundles/mobiscroll/js/mobiscroll.jquery.min.js"></script>

  <!-- Page Specific JS File -->
  <!--<script src="assets/js/page/forms-advanced-forms.js"></script>-->

  <script src="<?php echo BASE_URL; ?>assets/js/sweetalert2.all.min.js"></script>