<?php 

header('Location: '. BASE_URL . 'admin/home');
?>