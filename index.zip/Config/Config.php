<?php
const BASE_URL = "http://localhost/asistencia3/";
const HOST = "localhost";
const USER = "postgres";
const PASS = "123456";
const DB = "testeo5";
const CHARSET = "charset=utf8";
const TITLE = "asistencia";

// const BASE_URL = "https://declaracion.diresatacna.gob.pe/";
// const HOST = "192.141.41.70";
// const USER = "zqavzvpn_user_asistencia";
// const PASS = "4re1pczmaxk7vi5s";
// const DB = "zqavzvpn_bd_asistencia";
// const CHARSET = "charset=utf8";
// const TITLE = "asistencia";
// const MONEDA = "USD";
// const CLIENT_ID = "";

// const USER_SMTP = "Tu correo";
// const PASS_SMTP = "contraseña generada para esta aplicacion";
const PUERTO_SMTP = 465;
const PUERTO = 5432;
// const HOST_SMTP = "smtp.gmail.com";
?>
