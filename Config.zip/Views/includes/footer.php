<footer class="main-footer">
    <div class="footer-right">
        <img alt="image" src="<?php echo BASE_URL; ?>assets/img/icono_diresa.png" height="25px" class="header-logo" /> <span
                class="logo-name">Dirección Regional de Salud | Desarrollado por el equipo de informática</span>
        <!-- <a href="templateshub.net">Templateshub</a></a> -->
    </div>
    <div class="footer-right">
    </div>
</footer>